// src/environments/environment.ts
import Config from "../config.json";

export const environment = {
    production: false,
    apiUrl: Config.API_URL,
};